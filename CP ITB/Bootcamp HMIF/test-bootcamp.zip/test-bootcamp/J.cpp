/  Main.cpp
//
 
 
#include <bits/stdc++.h>
using namespace std;
 
//Define Lists
#define fi first
#define se second
#define pb push_back
#define sz(x) (int)x.size() 
#define all(x) (x).begin(), (x).end()
#define OPTIMATION ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
#define inp() freopen("in.txt", "r", stdin);
#define out() freopen("out.txt", "w", stdout);
#define IO inp() out()
 
//typedef Lists
typedef long long LL;
typedef pair<int,int> ii;
typedef vector<int> vi;
typedef vector<pair<int,int> > vii;
 
//constant values
const double pi = acos(-1);
const LL MODPRIMA = (LL)1e9 + 7;
const LL MAXX = (LL)1e18;
const LL MINN = -(LL)1e18;
const double EPS = 1e-9;
 
//functions and procedures list
void fastscan(int &number) { 
  bool negative = false; 
  register int c; 
  number = 0; 
  c = getchar(); 
  if (c=='-') { 
      negative = true; 
      c = getchar(); 
  } 
  for (; (c>47 && c<58); c=getchar()) 
      number = number *10 + c - 48; 
  if (negative) 
      number *= -1; 
} 
 
//declare variables here
const int MAXN = 1e5;
int T, N, Q, TC;
int arr[MAXN+3], prefix[MAXN+3], indeks[MAXN+3], frek[MAXN+3];
int prv, x, idx;
 
int main(){
  OPTIMATION
  cin >> T;
  while (T--) {
    cin >> N >> Q;
    for (int i = 0; i < N; i++) cin >> arr[i];
    int i = 0;
    int curr = 0;
    while (i < N) {
      frek[i] = curr+1;
      int j = i+1;
      while (j < N && arr[j] == arr[i]){
        frek[j] = frek[i];
        j++;
      }
      i = j;
      curr++;
    }
    int idx = 0;
    for (int i = 0; i < N; i++){
      if (i == 0) {
        prefix[idx] = frek[i];
        indeks[frek[i]] = idx;
        idx++;
      }else{
        if (frek[i] != prefix[idx-1]){
          prefix[idx] = frek[i];
          indeks[frek[i]] = idx;
          idx++;
        }
      }
    }
    // for (int i = 0; i < N; i++) cout << frek[i] << " "; cout << '\n';
    // for (int i = 0; i < idx; i++) cout << prefix[i] << " "; cout << '\n';
    // for (int i = 0; i < idx; i++) cout << indeks[prefix[i]] << " "; cout << '\n';
    cout << "Case " << ++TC << ":\n";
    while (Q--){
      int L, R;
      cin >> L >> R;
      L--; R--;
      int bR = frek[R];
      int bL = frek[L];
      int iL = indeks[bL];
      if (iL == 0) cout << bR << '\n';
      else cout << bR - prefix[iL-1] << '\n';
    }
  }  
  return 0;
} 