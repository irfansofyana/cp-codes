#pragma GCC optimize("Ofast")
#pragma GCC optimize ("unroll-loops")
#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,tune=native")
#include <bits/stdc++.h>
using namespace std;

//Define Lists
#define fi first
#define se second
#define pb push_back
#define sz(x) (int)x.size() 
#define all(x) (x).begin(), (x).end()
#define OPTIMATION ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
#define inp(x) freopen(x.txt, "r", stdin);
#define out(x) freopen(x.txt, "w", stdout);
#define IO inp() out()
#define spacnl(i, n) cout << (i == n-1 ? '\n' : ' ');

//typedef Lists
typedef long long LL;
typedef pair<int,int> ii;
typedef vector<int> vi;
typedef vector<pair<int,int> > vii;

//constant values
const double pi = acos(-1);
const LL MODPRIMA = (LL)1e9 + 7;
const LL MAXX = (LL)1e18;
const LL MINN = -(LL)1e18;
const double EPS = 1e-9;

//declare variables here
string s;
bool ada[500005];
int ans, tot;

int main(){
  OPTIMATION
  cin >> s;
  for (int i = (int)s.size()-1; i >= 0; i--){
  	if (i == (int)s.size()-1) {
  		if (s[i] == ']') ada[i] = true;
  		else ada[i] = false;
  	}else{
  		if (s[i] == ']') ada[i] = true;
  		else ada[i] = ada[i+1];
  	}
  }
  int i = 0;
  while (i < (int)s.size() && s[i] != '[') i++;
  while (i < (int)s.size() && s[i] != ':') i++;
  for (int j = i+1; j < (int)s.size(); j++){
  	if (s[j] == '|') tot++;
  	else if (s[j] == ':') {
  		if (j + 1 < (int)s.size() && ada[j+1])
  			ans = max(ans, tot + 4);
  	} 
  }
  cout << (ans == 0 ? -1 : ans) << '\n';
  return 0;
}